# CLEAN benchmark — автоматический технический отчёт

- Suite: **v2** (15 кейсов)
- Model: `/srv/ai/models/text/saiga_yandexgpt_8b.Q4_K_M.gguf`
- GGUF SHA-256: `9fa815411ee51b4f2b8cabfb01f969f1a919356c14c939b9b189e566ade145a8`
- Engine: `/opt/llama.cpp/build-cuda-p106/bin/llama-cli`; backend: `gpu`; -ngl: `99`
- Input verification: **canonical-v1**
- Successful runs: **15/15**

| Кейс | Status | Wall, с | Prompt, ток/с | Generation, ток/с | Peak RAM RSS, kB | Major | Swap | Exit | Ответ |
|---|---|---:|---:|---:|---:|---:|---:|---:|---|
| clean-v1-01 | ok | 11.99 | 354.4 | 22.0 | 5101584 | 0 | 0 | 0 | [heuristic:truncated_prompt](clean-v1-01/response.txt) |
| clean-v1-02 | ok | 12.83 | 355.5 | 22.0 | 5101552 | 0 | 0 | 0 | [heuristic:truncated_prompt](clean-v1-02/response.txt) |
| clean-v1-03 | ok | 13.14 | 352.1 | 21.9 | 5101488 | 0 | 0 | 0 | [heuristic:truncated_prompt](clean-v1-03/response.txt) |
| clean-v1-04 | ok | 12.83 | 353.0 | 21.9 | 5101468 | 0 | 0 | 0 | [heuristic:truncated_prompt](clean-v1-04/response.txt) |
| clean-v1-05 | ok | 11.48 | 352.7 | 22.1 | 5101416 | 0 | 0 | 0 | [heuristic:truncated_prompt](clean-v1-05/response.txt) |
| clean-v1-06 | ok | 12.32 | 350.8 | 21.9 | 5101676 | 0 | 0 | 0 | [heuristic:truncated_prompt](clean-v1-06/response.txt) |
| clean-v1-07 | ok | 21.7 | 352.4 | 21.9 | 5101420 | 0 | 0 | 0 | [heuristic:truncated_prompt](clean-v1-07/response.txt) |
| clean-v1-08 | ok | 12.48 | 348.2 | 21.8 | 5101632 | 0 | 0 | 0 | [heuristic:truncated_prompt](clean-v1-08/response.txt) |
| clean-v1-09 | ok | 11.98 | 350.4 | 21.8 | 5101500 | 0 | 0 | 0 | [heuristic:full_prompt](clean-v1-09/response.txt) |
| clean-v1-10 | ok | 16.76 | 350.8 | 21.8 | 5101540 | 0 | 0 | 0 | [heuristic:truncated_prompt](clean-v1-10/response.txt) |
| clean-v2-11 | ok | 11.74 | 349.9 | 21.9 | 5101528 | 0 | 0 | 0 | [heuristic:truncated_prompt](clean-v2-11/response.txt) |
| clean-v2-12 | ok | 12.88 | 348.4 | 21.8 | 5101572 | 0 | 0 | 0 | [heuristic:truncated_prompt](clean-v2-12/response.txt) |
| clean-v2-13 | ok | 13.29 | 347.9 | 21.9 | 5101596 | 0 | 0 | 0 | [heuristic:full_prompt](clean-v2-13/response.txt) |
| clean-v2-14 | ok | 12.07 | 349.7 | 21.8 | 5101468 | 0 | 0 | 0 | [heuristic:full_prompt](clean-v2-14/response.txt) |
| clean-v2-15 | ok | 11.61 | 349.6 | 21.7 | 5101388 | 0 | 0 | 0 | [heuristic:full_prompt](clean-v2-15/response.txt) |

- Mean prompt: **351.05 ток/с**
- Mean generation: **21.88 ток/с**
- Mean process wall: **13.27 с**

## Оценка качества (вручную)

- Первые CLEAN-01…10: **—/80** (дождаться ручной оценки по rubric.md).
- Дополнительные CLEAN-11…15: **—/40** (только suite v2).
- Общий итог CLEAN v2: **—/120** (только suite v2).
- Hard failures: **не оценены**. Отсутствие crash не означает отсутствие смысловых ошибок.

## Замечания по сопоставимости

- Каждый кейс — самостоятельный процесс llama-cli и отдельная загрузка модели.
- Настройки baseline CLEAN v1 сохранены, включая temperature=0.7 без fixed seed.
- Системная RAM RSS не равна GPU VRAM; power/temperature не измеряются этим скриптом.
- Статус извлечения reply с префиксом `heuristic` требует проверки сырого run.log.
- `-ngl != 99` или другой `--engine` образуют отдельный профиль скорости относительно старого GPU CLEAN.
- `—` означает отсутствие измерения или оценки, а не нулевое значение.
