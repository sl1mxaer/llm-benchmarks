# CLEAN benchmark — автоматический технический отчёт

- Suite: **v2** (15 кейсов)
- Model: `/srv/ai/models/text/Qwen3-4B-Instruct-2507-Q5_K_M.gguf`
- GGUF SHA-256: `66713ce35a58a82fe87642d4ec13425bf9b9a46800fff5c49a665ef5701439dc`
- Engine: `/opt/llama.cpp/build-cuda-p106/bin/llama-cli`; backend: `gpu`; -ngl: `99`
- Input verification: **canonical-v1**
- Successful runs: **15/15**

| Кейс | Status | Wall, с | Prompt, ток/с | Generation, ток/с | Peak RAM RSS, kB | Major | Swap | Exit | Ответ |
|---|---|---:|---:|---:|---:|---:|---:|---:|---|
| clean-v1-01 | ok | 10.04 | 508.4 | 30.1 | 3126060 | 4 | 0 | 0 | [heuristic:truncated_prompt](clean-v1-01/response.txt) |
| clean-v1-02 | ok | 11.15 | 501.4 | 29.9 | 3126004 | 0 | 0 | 0 | [heuristic:truncated_prompt](clean-v1-02/response.txt) |
| clean-v1-03 | ok | 9.92 | 496.9 | 30.0 | 3125924 | 0 | 0 | 0 | [heuristic:truncated_prompt](clean-v1-03/response.txt) |
| clean-v1-04 | ok | 10.9 | 497.5 | 29.9 | 3125992 | 0 | 0 | 0 | [heuristic:truncated_prompt](clean-v1-04/response.txt) |
| clean-v1-05 | ok | 10.1 | 501.7 | 29.9 | 3125936 | 0 | 0 | 0 | [heuristic:truncated_prompt](clean-v1-05/response.txt) |
| clean-v1-06 | ok | 10.9 | 495.8 | 29.8 | 3126068 | 0 | 0 | 0 | [heuristic:truncated_prompt](clean-v1-06/response.txt) |
| clean-v1-07 | ok | 9.19 | 493.5 | 29.8 | 3125976 | 0 | 0 | 0 | [heuristic:truncated_prompt](clean-v1-07/response.txt) |
| clean-v1-08 | ok | 10.5 | 501.6 | 29.9 | 3125992 | 0 | 0 | 0 | [heuristic:truncated_prompt](clean-v1-08/response.txt) |
| clean-v1-09 | ok | 10.72 | 501.8 | 29.8 | 3126012 | 0 | 0 | 0 | [heuristic:full_prompt](clean-v1-09/response.txt) |
| clean-v1-10 | ok | 14.62 | 491.2 | 29.6 | 3126088 | 0 | 0 | 0 | [heuristic:truncated_prompt](clean-v1-10/response.txt) |
| clean-v2-11 | ok | 9.96 | 499.7 | 29.8 | 3125980 | 0 | 0 | 0 | [heuristic:truncated_prompt](clean-v2-11/response.txt) |
| clean-v2-12 | ok | 10.71 | 496.9 | 29.8 | 3126028 | 0 | 0 | 0 | [heuristic:truncated_prompt](clean-v2-12/response.txt) |
| clean-v2-13 | ok | 10.99 | 492.1 | 29.7 | 3125776 | 0 | 0 | 0 | [heuristic:full_prompt](clean-v2-13/response.txt) |
| clean-v2-14 | ok | 9.93 | 494.4 | 29.8 | 3126128 | 0 | 0 | 0 | [heuristic:full_prompt](clean-v2-14/response.txt) |
| clean-v2-15 | ok | 10.08 | 497.2 | 29.8 | 3126160 | 0 | 0 | 0 | [heuristic:full_prompt](clean-v2-15/response.txt) |

- Mean prompt: **498.01 ток/с**
- Mean generation: **29.84 ток/с**
- Mean process wall: **10.65 с**

## Оценка качества (вручную)

- Первые CLEAN-01…10: **—/80** (дождаться ручной оценки по rubric.md).
- Дополнительные CLEAN-11…15: **—/40** (только suite v2).
- Общий итог CLEAN v2: **—/120** (только suite v2).
- Hard failures: **не оценены**. Отсутствие crash не означает отсутствие смысловых ошибок.

## Замечания по сопоставимости

- Каждый кейс — самостоятельный процесс llama-cli и отдельная загрузка модели.
- Настройки baseline CLEAN v1 сохранены, включая temperature=0.7 без fixed seed.
- Системная RAM RSS не равна GPU VRAM; power/temperature не измеряются этим скриптом.
- Статус извлечения reply с префиксом `heuristic` требует проверки сырого run.log.
- `-ngl != 99` или другой `--engine` образуют отдельный профиль скорости относительно старого GPU CLEAN.
- `—` означает отсутствие измерения или оценки, а не нулевое значение.
