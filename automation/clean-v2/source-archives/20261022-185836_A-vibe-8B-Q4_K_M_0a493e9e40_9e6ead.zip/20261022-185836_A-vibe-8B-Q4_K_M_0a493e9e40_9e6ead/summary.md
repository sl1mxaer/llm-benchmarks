# CLEAN benchmark — автоматический технический отчёт

- Suite: **v2** (15 кейсов)
- Model: `/srv/ai/models/text/A-vibe-8B-Q4_K_M.gguf`
- GGUF SHA-256: `0a493e9e40bcb6134c07e1af5258a4fb9d97cff695a2ae2d5ad4d6c963d53d1b`
- Engine: `/opt/llama.cpp/build-cuda-p106/bin/llama-cli`; backend: `gpu`; -ngl: `99`
- Input verification: **canonical-v1**
- Successful runs: **15/15**

| Кейс | Status | Wall, с | Prompt, ток/с | Generation, ток/с | Peak RAM RSS, kB | Major | Swap | Exit | Ответ |
|---|---|---:|---:|---:|---:|---:|---:|---:|---|
| clean-v1-01 | ok | 11.17 | 351.3 | 22.5 | 5010984 | 126 | 0 | 0 | [heuristic:truncated_prompt](clean-v1-01/response.txt) |
| clean-v1-02 | ok | 12.22 | 342.8 | 22.5 | 5010984 | 0 | 0 | 0 | [heuristic:truncated_prompt](clean-v1-02/response.txt) |
| clean-v1-03 | ok | 10.83 | 349.3 | 22.4 | 5011020 | 0 | 0 | 0 | [heuristic:truncated_prompt](clean-v1-03/response.txt) |
| clean-v1-04 | ok | 12.08 | 340.8 | 22.4 | 5011080 | 0 | 0 | 0 | [heuristic:truncated_prompt](clean-v1-04/response.txt) |
| clean-v1-05 | ok | 11.48 | 344.9 | 22.4 | 5010940 | 0 | 0 | 0 | [heuristic:truncated_prompt](clean-v1-05/response.txt) |
| clean-v1-06 | ok | 11.83 | 339.4 | 22.4 | 5010820 | 0 | 0 | 0 | [heuristic:truncated_prompt](clean-v1-06/response.txt) |
| clean-v1-07 | ok | 10.63 | 345.6 | 22.4 | 5011080 | 0 | 0 | 0 | [heuristic:truncated_prompt](clean-v1-07/response.txt) |
| clean-v1-08 | ok | 11.74 | 346.4 | 22.3 | 5010972 | 0 | 0 | 0 | [heuristic:truncated_prompt](clean-v1-08/response.txt) |
| clean-v1-09 | ok | 11.35 | 344.5 | 22.4 | 5010904 | 0 | 0 | 0 | [heuristic:full_prompt](clean-v1-09/response.txt) |
| clean-v1-10 | ok | 15.83 | 338.3 | 22.2 | 5010868 | 0 | 0 | 0 | [heuristic:truncated_prompt](clean-v1-10/response.txt) |
| clean-v2-11 | ok | 10.77 | 343.9 | 22.3 | 5010852 | 0 | 0 | 0 | [heuristic:truncated_prompt](clean-v2-11/response.txt) |
| clean-v2-12 | ok | 12.21 | 342.3 | 22.3 | 5010920 | 0 | 0 | 0 | [heuristic:truncated_prompt](clean-v2-12/response.txt) |
| clean-v2-13 | ok | 12.38 | 340.1 | 22.4 | 5011052 | 0 | 0 | 0 | [heuristic:full_prompt](clean-v2-13/response.txt) |
| clean-v2-14 | ok | 11.33 | 342.9 | 22.3 | 5010932 | 0 | 0 | 0 | [heuristic:full_prompt](clean-v2-14/response.txt) |
| clean-v2-15 | ok | 11.14 | 342.8 | 22.3 | 5011076 | 0 | 0 | 0 | [heuristic:full_prompt](clean-v2-15/response.txt) |

- Mean prompt: **343.69 ток/с**
- Mean generation: **22.37 ток/с**
- Mean process wall: **11.80 с**

## Оценка качества (вручную)

- Первые CLEAN-01…10: **—/80** (дождаться ручной оценки по rubric.md).
- Дополнительные CLEAN-11…15: **—/40** (только suite v2).
- Общий итог CLEAN v2: **—/120** (только suite v2).
- Hard failures: **не оценены**. Отсутствие crash не означает отсутствие смысловых ошибок.

## Замечания по сопоставимости

- Каждый кейс — самостоятельный процесс llama-cli и отдельная загрузка модели.
- Настройки baseline CLEAN v1 сохранены, включая temperature=0.7 без fixed seed.
- Системная RAM RSS не равна GPU VRAM; power/temperature не измеряются этим скриптом.
- Статус извлечения reply с префиксом `heuristic` требует проверки сырого run.log.
- `-ngl != 99` или другой `--engine` образуют отдельный профиль скорости относительно старого GPU CLEAN.
- `—` означает отсутствие измерения или оценки, а не нулевое значение.
