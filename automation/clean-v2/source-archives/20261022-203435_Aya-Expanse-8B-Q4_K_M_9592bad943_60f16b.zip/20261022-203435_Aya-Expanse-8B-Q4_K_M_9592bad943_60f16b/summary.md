# CLEAN benchmark — автоматический технический отчёт

- Suite: **v2** (15 кейсов)
- Model: `/srv/ai/models/text/Aya-Expanse-8B-Q4_K_M.gguf`
- GGUF SHA-256: `9592bad943fe56cf93200286a0a4b00a158cd84a408f227b9978ec5879002fb8`
- Engine: `/opt/llama.cpp/build-cuda-p106/bin/llama-cli`; backend: `gpu`; -ngl: `99`
- Input verification: **canonical-v1**
- Successful runs: **15/15**

| Кейс | Status | Wall, с | Prompt, ток/с | Generation, ток/с | Peak RAM RSS, kB | Major | Swap | Exit | Ответ |
|---|---|---:|---:|---:|---:|---:|---:|---:|---|
| clean-v1-01 | ok | 14.21 | 352.8 | 19.6 | 5281208 | 127 | 0 | 0 | [heuristic:truncated_prompt](clean-v1-01/response.txt) |
| clean-v1-02 | ok | 15.14 | 344.9 | 19.6 | 5281440 | 0 | 0 | 0 | [heuristic:truncated_prompt](clean-v1-02/response.txt) |
| clean-v1-03 | ok | 14.34 | 350.8 | 19.5 | 5281228 | 0 | 0 | 0 | [heuristic:truncated_prompt](clean-v1-03/response.txt) |
| clean-v1-04 | ok | 15.11 | 343.1 | 19.5 | 5281200 | 0 | 0 | 0 | [heuristic:truncated_prompt](clean-v1-04/response.txt) |
| clean-v1-05 | ok | 13.97 | 347.3 | 19.5 | 5281188 | 0 | 0 | 0 | [heuristic:truncated_prompt](clean-v1-05/response.txt) |
| clean-v1-06 | ok | 14.48 | 342.0 | 19.4 | 5281204 | 0 | 0 | 0 | [heuristic:truncated_prompt](clean-v1-06/response.txt) |
| clean-v1-07 | ok | 13.37 | 346.7 | 19.4 | 5281188 | 0 | 0 | 0 | [heuristic:truncated_prompt](clean-v1-07/response.txt) |
| clean-v1-08 | ok | 14.34 | 347.4 | 19.4 | 5281276 | 0 | 0 | 0 | [heuristic:truncated_prompt](clean-v1-08/response.txt) |
| clean-v1-09 | ok | 14.19 | 345.9 | 19.4 | 5281080 | 0 | 0 | 0 | [heuristic:full_prompt](clean-v1-09/response.txt) |
| clean-v1-10 | ok | 19.59 | 342.0 | 19.4 | 5281308 | 0 | 0 | 0 | [heuristic:truncated_prompt](clean-v1-10/response.txt) |
| clean-v2-11 | ok | 13.91 | 345.3 | 19.4 | 5281268 | 0 | 0 | 0 | [heuristic:truncated_prompt](clean-v2-11/response.txt) |
| clean-v2-12 | ok | 14.14 | 343.5 | 19.4 | 5281204 | 0 | 0 | 0 | [heuristic:truncated_prompt](clean-v2-12/response.txt) |
| clean-v2-13 | ok | 15.31 | 341.5 | 19.5 | 5281344 | 0 | 0 | 0 | [heuristic:full_prompt](clean-v2-13/response.txt) |
| clean-v2-14 | ok | 13.8 | 344.0 | 19.4 | 5281176 | 0 | 0 | 0 | [heuristic:full_prompt](clean-v2-14/response.txt) |
| clean-v2-15 | ok | 11.55 | 344.3 | 19.2 | 5281172 | 0 | 0 | 0 | [heuristic:full_prompt](clean-v2-15/response.txt) |

- Mean prompt: **345.43 ток/с**
- Mean generation: **19.44 ток/с**
- Mean process wall: **14.50 с**

## Оценка качества (вручную)

- Первые CLEAN-01…10: **—/80** (дождаться ручной оценки по rubric.md).
- Дополнительные CLEAN-11…15: **—/40** (только suite v2).
- Общий итог CLEAN v2: **—/120** (только suite v2).
- Hard failures: **не оценены**. Отсутствие crash не означает отсутствие смысловых ошибок.

## Замечания по сопоставимости

- Каждый кейс — самостоятельный процесс llama-cli и отдельная загрузка модели.
- Настройки baseline CLEAN v1 сохранены, включая temperature=0.7 без fixed seed.
- Системная RAM RSS не равна GPU VRAM; power/temperature не измеряются этим скриптом.
- Статус извлечения reply с префиксом `heuristic` требует проверки сырого run.log.
- `-ngl != 99` или другой `--engine` образуют отдельный профиль скорости относительно старого GPU CLEAN.
- `—` означает отсутствие измерения или оценки, а не нулевое значение.
