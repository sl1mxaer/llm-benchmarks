# CLEAN benchmark — автоматический технический отчёт

- Suite: **v2** (15 кейсов)
- Model: `/srv/ai/models/text/QVikhr-3-4B-Instruction-Q6_K.gguf`
- GGUF SHA-256: `4b75f6682b1d84c9048f54ffe5ddb54c7c5202afccb4121d027b59c227c31076`
- Engine: `/opt/llama.cpp/build-cuda-p106/bin/llama-cli`; backend: `gpu`; -ngl: `99`
- Input verification: **canonical-v1**
- Successful runs: **15/15**

| Кейс | Status | Wall, с | Prompt, ток/с | Generation, ток/с | Peak RAM RSS, kB | Major | Swap | Exit | Ответ |
|---|---|---:|---:|---:|---:|---:|---:|---:|---|
| clean-v1-01 | ok | 11.14 | 498.3 | 26.5 | 3533000 | 0 | 0 | 0 | [heuristic:truncated_prompt](clean-v1-01/response.txt) |
| clean-v1-02 | ok | 12.13 | 491.3 | 26.3 | 3533004 | 0 | 0 | 0 | [heuristic:truncated_prompt](clean-v1-02/response.txt) |
| clean-v1-03 | ok | 11.81 | 486.3 | 26.4 | 3532964 | 0 | 0 | 0 | [heuristic:truncated_prompt](clean-v1-03/response.txt) |
| clean-v1-04 | ok | 11.89 | 486.5 | 26.3 | 3532880 | 0 | 0 | 0 | [heuristic:truncated_prompt](clean-v1-04/response.txt) |
| clean-v1-05 | ok | 10.98 | 491.5 | 26.3 | 3532956 | 0 | 0 | 0 | [heuristic:truncated_prompt](clean-v1-05/response.txt) |
| clean-v1-06 | ok | 11.87 | 485.5 | 26.2 | 3532976 | 0 | 0 | 0 | [heuristic:truncated_prompt](clean-v1-06/response.txt) |
| clean-v1-07 | ok | 11.73 | 483.0 | 26.2 | 3532988 | 0 | 0 | 0 | [heuristic:truncated_prompt](clean-v1-07/response.txt) |
| clean-v1-08 | ok | 11.47 | 480.8 | 26.2 | 3532788 | 0 | 0 | 0 | [heuristic:truncated_prompt](clean-v1-08/response.txt) |
| clean-v1-09 | ok | 11.62 | 481.4 | 26.2 | 3533072 | 0 | 0 | 0 | [heuristic:full_prompt](clean-v1-09/response.txt) |
| clean-v1-10 | ok | 15.5 | 481.2 | 26.0 | 3532920 | 0 | 0 | 0 | [heuristic:truncated_prompt](clean-v1-10/response.txt) |
| clean-v2-11 | ok | 11.5 | 479.4 | 26.1 | 3533012 | 0 | 0 | 0 | [heuristic:truncated_prompt](clean-v2-11/response.txt) |
| clean-v2-12 | ok | 12.22 | 487.0 | 26.2 | 3532864 | 0 | 0 | 0 | [heuristic:truncated_prompt](clean-v2-12/response.txt) |
| clean-v2-13 | ok | 12.98 | 482.3 | 26.1 | 3532848 | 0 | 0 | 0 | [heuristic:full_prompt](clean-v2-13/response.txt) |
| clean-v2-14 | ok | 10.67 | 484.3 | 26.2 | 3532944 | 0 | 0 | 0 | [heuristic:full_prompt](clean-v2-14/response.txt) |
| clean-v2-15 | ok | 10.88 | 487.1 | 26.2 | 3533068 | 0 | 0 | 0 | [heuristic:full_prompt](clean-v2-15/response.txt) |

- Mean prompt: **485.73 ток/с**
- Mean generation: **26.23 ток/с**
- Mean process wall: **11.89 с**

## Оценка качества (вручную)

- Первые CLEAN-01…10: **—/80** (дождаться ручной оценки по rubric.md).
- Дополнительные CLEAN-11…15: **—/40** (только suite v2).
- Общий итог CLEAN v2: **—/120** (только suite v2).
- Hard failures: **не оценены**. Отсутствие crash не означает отсутствие смысловых ошибок.

## Замечания по сопоставимости

- Каждый кейс — самостоятельный процесс llama-cli и отдельная загрузка модели.
- Настройки baseline CLEAN v1 сохранены, включая temperature=0.7 без fixed seed.
- Системная RAM RSS не равна GPU VRAM; power/temperature не измеряются этим скриптом.
- Статус извлечения reply с префиксом `heuristic` требует проверки сырого run.log.
- `-ngl != 99` или другой `--engine` образуют отдельный профиль скорости относительно старого GPU CLEAN.
- `—` означает отсутствие измерения или оценки, а не нулевое значение.
